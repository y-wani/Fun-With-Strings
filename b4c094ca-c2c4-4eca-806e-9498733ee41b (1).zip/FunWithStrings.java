/**
 * DESCRIPTION OF PROGRAM HERE
 *
 * @author Yash Wani
 * @version 20210913
 */
import java.util.Scanner;

public class FunWithStrings {

    public static void main(String[] args) {
       
       Scanner sc = new Scanner(System.in);
       
       //Input for the string 
       System.out.print("Enter a long string: ");
       String ls = sc.nextLine();
       
       //Input for the substring
       System.out.print("Enter a substring: ");
       String substr = sc.nextLine();
       
       //Length of the String
       int len = ls.length();
       System.out.println("Length of your string: "+len);
       
       //Length of the Substring
       int len2 = substr.length();
       System.out.println("Length of your substring: "+len2);
       
       //Starting position of substring
       int pos = ls.indexOf(substr);
       System.out.println("Starting position of your substring: "+pos);
       
       //String before substring
       String befsub = ls.substring(0 , pos);
       System.out.println("String before your substring: "+befsub);
       
       //String after substring
       String aftsub = ls.substring((pos+len2) , len);
       System.out.println("String after your substring: "+aftsub);
       
       //Character ar Position
       System.out.print("Enter a position between 0 and "+(len-1)+": "); 
       int inpchar = sc.nextInt();
       sc.nextLine();
       char posi = ls.charAt(inpchar);
       System.out.println("The character at position "+inpchar+" is "+posi);
       
       //Replacement String
       System.out.print("Enter a replacement string: ");
       String repl = sc.nextLine();
       ls = ls.replace(substr , repl);
       System.out.println("Your new string is: "+ls);
       
       
       System.out.println("Goodbye!");
       
      
       
       
       
      
       

    }
}
